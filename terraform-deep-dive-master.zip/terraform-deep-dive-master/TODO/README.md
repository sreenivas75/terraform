# sops
# terragrunt
# To do demo --> https://blog.gruntwork.io/terraform-tips-tricks-loops-if-statements-and-gotchas-f739bbae55f9
# TO do practical demo --> https://blog.gruntwork.io/a-comprehensive-guide-to-managing-secrets-in-your-terraform-code-1d586955ace1
# TFSwitch
# TFLint
# Terraform-docs
# Checkov
# Infracost
## Reference --> https://betterprogramming.pub/5-essential-terraform-tools-to-use-everyday-e910a96e70d9
