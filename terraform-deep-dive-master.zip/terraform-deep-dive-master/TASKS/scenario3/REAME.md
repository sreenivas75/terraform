### Reference:
- [Resource tagging](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/guides/resource-tagging)
- [Datasource subnets](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/subnets)