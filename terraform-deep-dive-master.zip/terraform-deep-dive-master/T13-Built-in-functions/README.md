# Below are some of regulerally used built-in functions of Terraform 
## file
## element
## format
## merge
## join
## split
## length
## can
## lookup
## max
## min
## substr
## regex