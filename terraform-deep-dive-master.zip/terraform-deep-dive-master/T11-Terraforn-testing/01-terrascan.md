# TerraScan


### References
- [terrascan docker](https://runterrascan.io/docs/getting-started/#using-a-docker-container)
- [Format](https://runterrascan.io/docs/usage/command_line_mode/#configuring-the-output-format-for-a-scan)