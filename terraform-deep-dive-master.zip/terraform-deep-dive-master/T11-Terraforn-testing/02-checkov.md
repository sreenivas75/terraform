### References:
- [checkov](https://github.com/bridgecrewio/checkov?ref=thechiefio)