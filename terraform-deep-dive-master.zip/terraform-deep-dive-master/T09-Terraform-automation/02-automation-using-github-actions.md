### References:
- [GitHub Actions](https://docs.github.com/en/actions)
- [Terraform GitHub Actions Exaqmple](https://learn.hashicorp.com/tutorials/terraform/github-actions?in=terraform/automation)
- [hashicorp-terraform-marketplace](https://github.com/marketplace/actions/hashicorp-setup-terraform)